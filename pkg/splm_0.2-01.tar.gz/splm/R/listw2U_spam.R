`listw2U_spam` <-
function(lw){
0.5 * (lw + t(lw))
}

