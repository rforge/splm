`vcov.splm` <-
function(x) return(x$vcov)

